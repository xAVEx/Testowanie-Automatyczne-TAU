def wyswietl_plansze(values):
    print("\n")
    print("\t     |     |")
    print("\t  {}  |  {}  |  {}".format(values[0], values[1], values[2]))
    print('\t_____|_____|_____')

    print("\t     |     |")
    print("\t  {}  |  {}  |  {}".format(values[3], values[4], values[5]))
    print('\t_____|_____|_____')

    print("\t     |     |")

    print("\t  {}  |  {}  |  {}".format(values[6], values[7], values[8]))
    print("\t     |     |")
    print("\n")


def wyswietl_instrukcje():
    print("\n")
    print("\t------------------")
    print("\t    INSTRUKCJA    ")
    print("\t------------------")
    print("\t     |     |")
    print("\t  1  |  2  |  3")
    print('\t_____|_____|_____')

    print("\t     |     |")
    print("\t  4  |  5  |  6")
    print('\t_____|_____|_____')

    print("\t     |     |")

    print("\t  7  |  8  |  9")
    print("\t     |     |")
    print("\n")


# Funkcja wyświetlająca wyniki
def wyswietl_wynik(tablica_wynikow):
    print("\t-------------------")
    print("\t      WYNIKI       ")
    print("\t-------------------")

    players = list(tablica_wynikow.keys())
    print("\t   ", players[0], "\t    ", tablica_wynikow[players[0]])
    print("\t   ", players[1], "\t    ", tablica_wynikow[players[1]])

    print("\t-------------------\n")


# Funkcja sprawdzająca, czy któryś z graczy wygrał
def sprawdz_wygrana(pozycja, gracz):

    soln = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [1, 4, 7], [2, 5, 8], [3, 6, 9], [1, 5, 9], [3, 5, 7]]

    for x in soln:
        if all(y in pozycja[gracz] for y in x):
            return True
    return False


# Funkcja sprawdzająca czy nie zapadł remis podczas gry
def sprawdz_remis(pozycja):
    if len(pozycja['X']) + len(pozycja['O']) == 9:
        return True
    return False


def single_game(gracz):

    values = [' ' for x in range(9)]

    pozycja = {'X': [], 'O': []}

    while True:
        wyswietl_plansze(values)

        try:
            print("Ruch Gracza ", gracz, " Które polę chcesz wybrać?? : ", end="")
            move = int(input())
        except ValueError:
            print("WYBIERZ CYFRĘ OD 1 DO 9")
            continue

        if move < 1 or move > 9:
            print("WYBIERZ CYFRĘ OD 1 DO 9")
            continue

        if values[move - 1] != ' ':
            print("TO POLE JEST JUŻ ZAJĘTE WYBIERZ INNE")
            continue

        values[move - 1] = gracz

        pozycja[gracz].append(move)

        if sprawdz_wygrana(pozycja, gracz):
            wyswietl_plansze(values)
            print("GRACZ ", gracz, " WYGRAŁ GRĘ GRATULACJĘ!!!")
            print("\n")
            return gracz

        if sprawdz_remis(pozycja):
            wyswietl_plansze(values)
            print("REMIS")
            print("\n")
            return 'D'

        if gracz == 'X':
            gracz = 'O'
        else:
            gracz = 'X'


if __name__ == "__main__":

    print("Gracz nr 1")
    player1 = input("Wpisz nazwę gracza : ")
    print("\n")

    print("Gracz nr 2")
    player2 = input("Wpisz nazwę gracza : ")
    print("\n")

    gracz = player1

    wybor_gracza = {'X': "", 'O': ""}

    options = ['X', 'O']

    tablica_wynikow = {player1: 0, player2: 0}
    wyswietl_wynik(tablica_wynikow)
    wyswietl_instrukcje()

    while True:

        print("W tej turze pierwszeństwo wyboru ma gracz", gracz)
        print("Wybierz 1 jeżeli chcesz grać jako X")
        print("Wybierz 2 jeżeli chcesz grać jako O")
        print("Wybierz 3 jeżeli chcesz opuścić Grę")

        try:
            wybor = int(input())
        except ValueError:
            print("Wybrałeś zły klawisz spróbuj inny\n")
            continue

        if wybor == 1:
            wybor_gracza['X'] = gracz
            if gracz == player1:
                wybor_gracza['O'] = player2
            else:
                wybor_gracza['O'] = player1

        elif wybor == 2:
            wybor_gracza['O'] = gracz
            if gracz == player1:
                wybor_gracza['X'] = player2
            else:
                wybor_gracza['X'] = player1

        elif wybor == 3:
            print("WYNIK KOŃCOWY")
            wyswietl_wynik(tablica_wynikow)
            break

        else:
            print("Wybrałeś zły klawisz spróbuj inny\n")
            continue

        winner = single_game(options[wybor - 1])

        if winner != 'D':
            player_won = wybor_gracza[winner]
            tablica_wynikow[player_won] = tablica_wynikow[player_won] + 1

        wyswietl_wynik(tablica_wynikow)
        wyswietl_instrukcje()

        if gracz == player1:
            gracz = player2
        else:
            gracz = player1
            gracz = player1
