from main import wyswietl_plansze, wyswietl_wynik, sprawdz_wygrana, sprawdz_remis


def test_if_board_is_correctly_printed(capsys):
    test_values = ["X", "X", "O", "X", "X", "X", "O", "O", "O"]
    wyswietl_plansze(test_values)

    captured = capsys.readouterr()

    assert "X" in str(captured)
    assert "O" in str(captured)
    assert "_" in str(captured)
    assert "|" in str(captured)


def test_if_score_board_is_correctly_prited(capsys):
    test_values = {"1": 1, "2": 2}
    wyswietl_wynik(test_values)

    captured = capsys.readouterr()

    assert "WYNIKI" in str(captured)
    assert "1" in str(captured)
    assert "2" in str(captured)


def test_check_win_for_winning_combination():
    test_values = {'X': [1, 2, 3], 'O': []}

    assert sprawdz_wygrana(test_values, "X") is True


def test_check_win_for_lost_combination():
    test_values = {'X': [1, 2, 4], 'O': []}

    assert sprawdz_wygrana(test_values, "X") is False


def test_check_if_the_game_is_draw():
    test_values = {'X': [2, 5, 6, 7, 9], 'O': [1, 3, 4, 8]}

    assert sprawdz_remis(test_values) is True


